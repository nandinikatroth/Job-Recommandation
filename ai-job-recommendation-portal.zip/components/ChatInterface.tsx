
import React, { useRef, useEffect } from 'react';
import { ChatMessage, ModalField } from '../types';
import Message from './Message';
import ActionButtons from './ActionButtons';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onOpenModal: (field: ModalField) => void;
  onActionClick: (action: 'hiring' | 'skills') => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading, onOpenModal, onActionClick }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {messages.map((msg) => (
          <Message key={msg.id} message={msg} />
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-700 rounded-lg p-3 max-w-lg animate-pulse flex items-center space-x-2">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-75"></div>
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-150"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>
      <footer className="bg-slate-800/50 backdrop-blur-sm border-t border-slate-700 p-4 sticky bottom-0">
        <ActionButtons onOpenModal={onOpenModal} onActionClick={onActionClick} disabled={isLoading} />
      </footer>
    </div>
  );
};

export default ChatInterface;
