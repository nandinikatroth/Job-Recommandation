
import React from 'react';
import { ModalField } from '../types';
import { Book, Lightbulb, GraduationCap, MapPin, Rocket, Briefcase, BrainCircuit } from 'lucide-react';
import { PROFILE_FIELDS, ACTION_BUTTONS } from '../constants';

interface ActionButtonsProps {
  onOpenModal: (field: ModalField) => void;
  onActionClick: (action: 'hiring' | 'skills') => void;
  disabled: boolean;
}

const icons: Record<ModalField, React.ElementType> = {
  education: GraduationCap,
  skills: Lightbulb,
  experience: Briefcase,
  location: MapPin,
  goals: Rocket,
};

const ActionButtons: React.FC<ActionButtonsProps> = ({ onOpenModal, onActionClick, disabled }) => {
  const profileKeys = Object.keys(PROFILE_FIELDS) as ModalField[];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:flex md:flex-wrap md:justify-center gap-2">
      {profileKeys.map(field => {
        const Icon = icons[field];
        return (
          <button
            key={field}
            onClick={() => onOpenModal(field)}
            disabled={disabled}
            className="flex items-center justify-center text-sm font-medium p-2 bg-slate-700 hover:bg-slate-600 rounded-md transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Icon className="h-4 w-4 mr-2" />
            {PROFILE_FIELDS[field]}
          </button>
        );
      })}
      {ACTION_BUTTONS.map(button => (
        <button
          key={button.action}
          onClick={() => onActionClick(button.action)}
          disabled={disabled}
          className="flex items-center justify-center text-sm font-medium p-2 bg-cyan-600 hover:bg-cyan-500 rounded-md transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed col-span-2 sm:col-span-1"
        >
          {button.label}
        </button>
      ))}
    </div>
  );
};

export default ActionButtons;
