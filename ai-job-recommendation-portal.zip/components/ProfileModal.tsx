
import React, { useState, useEffect, useRef } from 'react';
import { ModalField } from '../types';
import { X } from 'lucide-react';

interface ProfileModalProps {
  field: ModalField;
  label: string;
  currentValue: string;
  onClose: () => void;
  onSave: (field: ModalField, value: string) => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ field, label, currentValue, onClose, onSave }) => {
  const [value, setValue] = useState(currentValue);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onSave(field, value);
    }
  };

  return (
    <div 
        className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50"
        onClick={onClose}
    >
      <div 
        className="bg-slate-800 rounded-lg shadow-2xl p-6 w-full max-w-lg relative border border-slate-700"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-3 right-3 text-slate-400 hover:text-white transition-colors"
        >
          <X size={24} />
        </button>
        <h2 className="text-2xl font-bold mb-4 text-cyan-400">Update Your {label}</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor={field} className="block text-sm font-medium text-slate-300 mb-2">
            Please provide details about your {label.toLowerCase()}.
          </label>
          <textarea
            id={field}
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="w-full h-32 p-3 bg-slate-900 border border-slate-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-shadow text-white resize-none"
            placeholder={
                field === 'skills' ? 'e.g., Python, TensorFlow, PyTorch, SQL, Scikit-learn, Natural Language Processing' :
                field === 'experience' ? 'e.g., Entry-level, 2 years in data analysis, Senior ML Engineer' :
                'Tell me more...'
            }
          />
          <div className="mt-6 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2 bg-cyan-600 text-white font-semibold rounded-md hover:bg-cyan-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 transition-all duration-200 disabled:opacity-50"
              disabled={!value.trim()}
            >
              Save & Continue
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileModal;
