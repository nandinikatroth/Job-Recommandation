
import React from 'react';
import { ChatMessage } from '../types';
import { User, Bot, Briefcase, Target, ArrowRight, BookOpen } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MessageProps {
  message: ChatMessage;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const isAI = message.sender === 'ai';

  if (isAI && message.recommendations) {
    return (
      <div className="flex items-start gap-3 justify-start">
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-cyan-500 flex items-center justify-center">
          <Bot className="h-6 w-6 text-white" />
        </div>
        <div className="space-y-4 max-w-2xl">
            <p className="font-bold text-lg text-cyan-300">Here are your personalized job recommendations:</p>
            {message.recommendations.map((rec, index) => (
                <div key={index} className="bg-slate-800 rounded-lg p-5 border border-slate-700 shadow-lg transition-transform hover:scale-105 hover:border-cyan-500">
                    <h3 className="text-xl font-bold text-cyan-400 flex items-center mb-2"><Briefcase className="mr-2 h-5 w-5" />{rec.jobTitle}</h3>
                    <p className="text-slate-300 mb-4">{rec.jobDescription}</p>
                    <div className="mb-4">
                        <h4 className="font-semibold text-slate-100 flex items-center mb-2"><Target className="mr-2 h-5 w-5 text-green-400" />Why it's a good match:</h4>
                        <p className="text-slate-300 italic">"{rec.whyGoodMatch}"</p>
                    </div>
                    <div>
                        <h4 className="font-semibold text-slate-100 flex items-center mb-2"><BookOpen className="mr-2 h-5 w-5 text-purple-400"/>Next Steps:</h4>
                        <ul className="list-none space-y-2">
                            {rec.nextSteps.map((step, i) => (
                                <li key={i} className="flex items-start text-slate-300">
                                    <ArrowRight className="h-4 w-4 mr-3 mt-1 flex-shrink-0 text-cyan-400" />
                                    <span>{step}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`flex items-start gap-3 ${isAI ? 'justify-start' : 'justify-end'}`}>
      {isAI && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-cyan-500 flex items-center justify-center">
          <Bot className="h-6 w-6 text-white" />
        </div>
      )}
      <div className={`rounded-lg px-4 py-3 max-w-xl ${isAI ? 'bg-slate-700 text-gray-200' : 'bg-blue-600 text-white'}`}>
        <Markdown remarkPlugins={[remarkGfm]}
            components={{
                h1: ({node, ...props}) => <h1 className="text-2xl font-bold my-2" {...props} />,
                h2: ({node, ...props}) => <h2 className="text-xl font-bold my-2" {...props} />,
                h3: ({node, ...props}) => <h3 className="text-lg font-bold my-2" {...props} />,
                ul: ({node, ...props}) => <ul className="list-disc list-inside my-2 space-y-1" {...props} />,
                ol: ({node, ...props}) => <ol className="list-decimal list-inside my-2 space-y-1" {...props} />,
                p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                strong: ({node, ...props}) => <strong className="font-bold text-cyan-300" {...props} />,
            }}
        >
            {message.text || ''}
        </Markdown>
      </div>
      {!isAI && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center">
          <User className="h-6 w-6 text-white" />
        </div>
      )}
    </div>
  );
};

export default Message;
