
import { ChatMessage, ModalField } from './types';

export const SYSTEM_INSTRUCTION = `You are an intelligent AI Career Assistant designed to help users explore and prepare for careers in Artificial Intelligence and related fields. Your primary goal is to provide accurate, relevant, and user-friendly job recommendations, insights, and career guidance. You act as a virtual career counselor specializing in AI, data science, and machine learning jobs. Maintain a friendly, motivating, and professional tone. Always format responses neatly using headings, bullet points, or emojis for clarity and engagement.`;

export const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 1,
    sender: 'ai',
    text: "👋 Hello! I'm your AI Career Assistant. To get started, please tell me about your background by clicking the buttons below. The more I know, the better I can tailor job recommendations for you!",
  },
];

export const PROFILE_FIELDS: Record<ModalField, string> = {
  education: 'Education',
  skills: 'Skills',
  experience: 'Experience Level',
  location: 'Preferred Location',
  goals: 'Career Goals',
};

export const ACTION_BUTTONS = [
    { label: "🏢 Who's Hiring?", action: 'hiring', prompt: "List top industries and companies currently hiring AI professionals, and explain why they are significant in the AI space."},
    { label: "🧠 What Skills Are Required?", action: 'skills', prompt: "List the most trending and essential technical and soft skills in the AI job market. Use markdown for formatting."}
] as const;
