
export interface ChatMessage {
  id: number;
  sender: 'user' | 'ai';
  text?: string;
  recommendations?: JobRecommendation[];
}

export interface JobRecommendation {
  jobTitle: string;
  jobDescription: string;
  whyGoodMatch: string;
  nextSteps: string[];
}

export interface UserProfile {
  education: string;
  skills: string;
  experience: string;
  location: string;
  goals: string;
}

export type ModalField = keyof UserProfile;
