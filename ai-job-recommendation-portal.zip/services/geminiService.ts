import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, JobRecommendation } from '../types';
import { SYSTEM_INSTRUCTION } from '../constants';

// FIX: Per @google/genai guidelines, API key should be passed directly without type assertion.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const jobRecommendationSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      jobTitle: {
        type: Type.STRING,
        description: "The title of the recommended job.",
      },
      jobDescription: {
        type: Type.STRING,
        description: "A short, engaging description of the job role.",
      },
      whyGoodMatch: {
        type: Type.STRING,
        description: "A clear explanation of why this role is a good match for the user's profile.",
      },
      nextSteps: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING,
        },
        description: "Actionable next steps like courses, certifications, or portfolio tips.",
      },
    },
    required: ["jobTitle", "jobDescription", "whyGoodMatch", "nextSteps"],
  },
};

export const getJobRecommendations = async (profile: UserProfile): Promise<JobRecommendation[]> => {
  const prompt = `
    Based on the following user profile, please recommend 3-5 AI-related job roles that are the best fit.

    User Profile:
    - Education: ${profile.education}
    - Skills: ${profile.skills}
    - Experience Level: ${profile.experience}
    - Preferred Location: ${profile.location}
    - Career Goals: ${profile.goals}

    Return the recommendations in the specified JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
        responseSchema: jobRecommendationSchema,
        temperature: 0.5,
      },
    });

    const jsonString = response.text.trim();
    const recommendations = JSON.parse(jsonString) as JobRecommendation[];
    return recommendations;
  } catch (error) {
    console.error("Gemini API call failed for recommendations:", error);
    throw new Error("Failed to generate job recommendations.");
  }
};


export const getGenericInfo = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
                temperature: 0.7,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Gemini API call failed for generic info:", error);
        throw new Error("Failed to fetch information.");
    }
};