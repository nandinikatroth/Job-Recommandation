import React, { useState, useCallback, useEffect } from 'react';
import { ChatMessage, UserProfile, ModalField, JobRecommendation } from './types';
import { getJobRecommendations, getGenericInfo } from './services/geminiService';
import { INITIAL_MESSAGES, PROFILE_FIELDS, ACTION_BUTTONS } from './constants';
import ChatInterface from './components/ChatInterface';
import ProfileModal from './components/ProfileModal';
import { BrainCircuit } from 'lucide-react';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [currentModalField, setCurrentModalField] = useState<ModalField | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    education: '',
    skills: '',
    experience: '',
    location: '',
    goals: '',
  });

  const addMessage = (message: Omit<ChatMessage, 'id'>) => {
    setMessages(prev => [...prev, { ...message, id: Date.now() + Math.random() }]);
  };

  const handleOpenModal = (field: ModalField) => {
    setCurrentModalField(field);
    setIsModalOpen(true);
  };

  const handleProfileUpdate = (field: ModalField, value: string) => {
    const updatedProfile = { ...userProfile, [field]: value };
    setUserProfile(updatedProfile);
    setIsModalOpen(false);
    setCurrentModalField(null);
    addMessage({
      sender: 'user',
      text: `Updated ${PROFILE_FIELDS[field]}: ${value}`,
    });

    // Check if all fields are filled to trigger recommendation
    // FIX: Add type guard to ensure `val` is a string before calling `trim()`
    const allFieldsFilled = Object.values(updatedProfile).every(val => typeof val === 'string' && val.trim() !== '');
    if (allFieldsFilled) {
        handleGetRecommendations(updatedProfile);
    } else {
        addMessage({
          sender: 'ai',
          text: `Thanks for updating your ${PROFILE_FIELDS[field]}. Please provide the rest of your details so I can find the best jobs for you.`,
        });
    }
  };
  
  const handleGetRecommendations = useCallback(async (profile: UserProfile) => {
    setIsLoading(true);
    addMessage({
      sender: 'ai',
      text: "Great! I have all your details. Analyzing your profile to find the perfect AI-related jobs for you...",
    });

    try {
      const recommendations: JobRecommendation[] = await getJobRecommendations(profile);
      addMessage({
        sender: 'ai',
        recommendations: recommendations,
      });
    } catch (error) {
      console.error("Error fetching job recommendations:", error);
      addMessage({
        sender: 'ai',
        text: "I'm sorry, I encountered an error while generating your job recommendations. Please try again later.",
      });
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleActionClick = useCallback(async (action: 'hiring' | 'skills') => {
    const prompt = action === 'hiring' ? ACTION_BUTTONS[0].prompt : ACTION_BUTTONS[1].prompt;
    const userMessage = action === 'hiring' ? "Who's hiring in the AI space?" : "What skills are required for AI jobs?";
    
    addMessage({ sender: 'user', text: userMessage });
    setIsLoading(true);
    
    try {
        const responseText = await getGenericInfo(prompt);
        addMessage({ sender: 'ai', text: responseText });
    } catch (error) {
        console.error(`Error fetching ${action} info:`, error);
        addMessage({ sender: 'ai', text: `Sorry, I couldn't fetch information about ${action} right now.` });
    } finally {
        setIsLoading(false);
    }
  }, []);

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-gray-100 font-sans">
      <header className="flex items-center p-4 border-b border-slate-700 shadow-md bg-slate-800/50 backdrop-blur-sm">
        <BrainCircuit className="h-8 w-8 text-cyan-400 mr-3" />
        <h1 className="text-xl font-bold text-gray-100 tracking-wider">AI Job Recommendation Portal</h1>
      </header>
      <ChatInterface
        messages={messages}
        isLoading={isLoading}
        onOpenModal={handleOpenModal}
        onActionClick={handleActionClick}
      />
      {isModalOpen && currentModalField && (
        <ProfileModal
          field={currentModalField}
          label={PROFILE_FIELDS[currentModalField]}
          currentValue={userProfile[currentModalField]}
          onClose={() => setIsModalOpen(false)}
          onSave={handleProfileUpdate}
        />
      )}
    </div>
  );
};

export default App;